/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.compilado.main;

import br.com.compilador.exception.IsiLexicalException;
import br.com.compilador.lexico.IsiScanner;
import br.com.compilador.lexico.Token;

/**
 *
 * @author jhoni
 */
public class Main {
    public static void main(String[] args) {
        
            IsiScanner sc = new IsiScanner("C:\\Users\\jhoni\\Documents\\NetBeansProjects\\AnalisadorLexico\\src\\input.isi.txt");
            Token token = null;
            do{
                token = sc.nextToken();
                if(token != null){
                    System.out.println(token);
            }
            }while(token != null);
        
    }
}
