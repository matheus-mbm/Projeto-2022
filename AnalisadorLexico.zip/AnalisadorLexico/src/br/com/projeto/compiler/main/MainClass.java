/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.projeto.compiler.main;

import br.com.projeto.exception.IsiLexicalException;
import br.com.projeto.lexico.IsiScanner;
import br.com.projeto.lexico.Token;


public class MainClass {
    public static void main(String[] args) {
        try{
        IsiScanner sc = new IsiScanner("input.isi");
        Token token = null;
        do{
         token = sc.nextToken();
         if (token != null){
             System.out.println(token);
         }
        } while(token != null);
        }
        catch(IsiLexicalException ex){
            System.out.println("Lexical ERROR "+ex.getMessage());
        }
        catch(Exception ex){
          System.out.println("Generic Error");
        }
    }
}
