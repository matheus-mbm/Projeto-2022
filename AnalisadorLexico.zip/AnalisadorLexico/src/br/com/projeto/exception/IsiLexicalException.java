/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.projeto.exception;

/**
 *
 * @author adria
 */
public class IsiLexicalException extends RuntimeException {
    public IsiLexicalException(String msg){
      super(msg);
    }
}
